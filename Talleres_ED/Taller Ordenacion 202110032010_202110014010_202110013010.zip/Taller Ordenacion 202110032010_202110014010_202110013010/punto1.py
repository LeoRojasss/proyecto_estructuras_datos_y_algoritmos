def eliminarElementosDuplicados(lista):
   
     ListaSinDuplicados = []
     for i in lista:
      if i not in ListaSinDuplicados:
          ListaSinDuplicados.append(i)
     print(ListaSinDuplicados)


a = [4,7,11,4,9,5,11,7,3,5]
print(a)
eliminarElementosDuplicados(a)