def findMatrix(matrix,number):
    find = False
    for i in matrix:
        for j in i:
            if number in i:
                find = True
            else:
                continue
    return find

matrix = [[1,2,3,4],[5,6,7,8],[9,10,11,12]]
print(findMatrix(matrix,20))