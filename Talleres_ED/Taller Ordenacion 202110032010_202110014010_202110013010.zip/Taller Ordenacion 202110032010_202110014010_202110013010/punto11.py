import random

list_a = []
list_b = []
list_c = []

for i in range(100):
    list_a.append(random.randint(0,1000))

for i in range(60):
    list_b.append(random.randint(0,1000))

for i in list_a:
    list_c.append(i)

for i in list_b:
    list_c.append(i)

def quick_sort(lista):
    izquierda = []
    derecha = []
    centro=[] 

    if len(lista) >1:
        pivote = lista[-1]
        for i in lista:
            if i<pivote:
                izquierda.append(i)
            elif i==pivote:
                    centro.append(i)
            else:
                    derecha.append(i)
        return quick_sort(izquierda) + centro + quick_sort(derecha)
    else:
        return lista

lista_sin_duplicados=[]

for i in list_c:
    if i not in lista_sin_duplicados:
        lista_sin_duplicados.append(i)

print(quick_sort(lista_sin_duplicados),"\n",quick_sort(list_a),"\n",quick_sort(list_b))