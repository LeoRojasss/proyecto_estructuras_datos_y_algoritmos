def removerDuplicadosVector(arreglo, n):
 
    if n == 0 or n == 1:
        return n
 
    temp = list(range(n))
 
    d = 0;
    for i in range(0, n-1):
 
     
        if arreglo[i] != arreglo[i+1]:
            temp[d] = arreglo[i]
            d += 1
 
    temp[d] = arreglo[n-1]
    d += 1
     
    
    for i in range(0, d):
        arreglo[i] = temp[i]
 
    return d
 
arreglo = [1, 2, 2, 3, 4, 4, 4, 5, 5, 7,7,9,9,9,]
n = len(arreglo)
 
n = removerDuplicadosVector(arreglo, n)
 
for i in range(n):
    print ("%d"%(arreglo[i]), end = " ")