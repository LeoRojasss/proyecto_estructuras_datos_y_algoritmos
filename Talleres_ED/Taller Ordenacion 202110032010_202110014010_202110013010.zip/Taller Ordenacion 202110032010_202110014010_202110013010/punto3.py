def ordenamiento_por_inserccion(lista):
 for indice in range(1,len(lista)):
     valor =lista[indice]
     i=indice - 1
     while i>= 0:
         if valor < lista[i]:
          lista[i+1] =lista [i]
          lista[i] = valor
          i = i - 1
          print (lista)
         else:
             break

d = [47,3,21,32,56,92]
print(d)
ordenamiento_por_inserccion(d)
print (d)
