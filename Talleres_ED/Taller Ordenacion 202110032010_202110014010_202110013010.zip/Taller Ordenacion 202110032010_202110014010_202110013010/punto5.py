a = [1,1,2,3,8,5,1,2,4,5]

def contar(datos):
  result = {}
  for dato in datos:
    if dato not in result:
      result[dato] = 0
    result[dato] += 1
  return result 

cuenta = contar(a)

{1: 2, 2: 2, 3: 1}

dic_inverso = {}
for dato, repeticiones in cuenta.items():
  if repeticiones not in dic_inverso:
    dic_inverso[repeticiones] = []
  dic_inverso[repeticiones].append(dato) 

{1: [3], 2: [1, 2]}

max_rep = max(dic_inverso)
min_rep = min(dic_inverso)

print(f"el ganador en las votaciones es:  {dic_inverso[max_rep]} con {max_rep} votos")