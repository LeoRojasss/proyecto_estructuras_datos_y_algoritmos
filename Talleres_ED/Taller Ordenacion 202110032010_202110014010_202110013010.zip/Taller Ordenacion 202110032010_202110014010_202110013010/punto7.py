import time
from typing import final

inicio = time.time()
def negative_value(list):

    negative_list = []

    for i in range(len(list)):
        if list[i] < 0:
            negative_list.append(list[i])
        else:
            continue
    return negative_list


lista = [-1,-5,-4,-9,-4,-1,-2,-6,-12,-16,-19,-21,-25,-34,-56,-66,-77,-78,-80,-81,-83,-84,-87,-89,-90,-96,-99,-100]
print(negative_value(lista))

fin = time.time()

print(fin - inicio)